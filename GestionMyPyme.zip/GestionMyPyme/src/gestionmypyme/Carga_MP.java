/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionmypyme;

/**
 *
 * @author dtoma
 */
public class Carga_MP {
    
    public static void main(String []args){
    Menu_de_Carga pre = new Menu_de_Carga();
        pre.setVisible(true);
        Login1 iniciar= new Login1();
        try{
            for(int i=0;i<=100;i++){
            Thread.sleep(40);
            pre.progreso.setText(Integer.toString(i)+"%");
            pre.barra.setValue(i);
            
            if(i==100){
                pre.setVisible(false);
                iniciar.setVisible(true);
                
               }
            }
        }
        catch(Exception ex){
            
        }
}
}
